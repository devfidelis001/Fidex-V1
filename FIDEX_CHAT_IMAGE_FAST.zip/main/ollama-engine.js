"use strict";
// FIDEX's own local Ollama engine: a dedicated instance on its own port whose model folder lives inside the FIDEX folder
// (OLLAMA_MODELS). It never touches a normal Ollama installation that may already be running on 11434.
const { spawn } = require("child_process");
const http = require("http");
const fs = require("fs");
const path = require("path");

const HOST = process.env.FIDEX_OLLAMA_HOST || "http://127.0.0.1:11435";
const MODEL = process.env.FIDEX_OLLAMA_MODEL || "qwen3.5:4b"; // Take Over, Guide Me, vision, research (Python backend)
const CHAT_MODEL = process.env.FIDEX_CHAT_MODEL || "qwen3.5:2b"; // ordinary Chat only
// Optional CPU thread override for Chat only (unset = Ollama decides). Chat and warm-up must use identical runner options, or Ollama reloads the model.
const VISION_MODEL = process.env.FIDEX_VISION_MODEL || ""; // optional smaller/faster model just for reading images
const RUNNER = { ...(Number(process.env.FIDEX_CHAT_NUM_THREAD) > 0 ? { num_thread: Number(process.env.FIDEX_CHAT_NUM_THREAD) } : {}), num_gpu: Number(process.env.FIDEX_CHAT_NUM_GPU) > 0 ? Number(process.env.FIDEX_CHAT_NUM_GPU) : 999 }; // FIDEX_CHAT_NUM_GPU=999 forces all layers on the GPU
let child = null;
let readyPromise = null;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function ping(timeout = 700) {
  return new Promise((resolve) => {
    const req = http.get(HOST + "/api/version", { timeout }, (res) => { res.resume(); resolve(res.statusCode === 200); });
    req.on("error", () => resolve(false));
    req.on("timeout", () => { req.destroy(); resolve(false); });
  });
}

function findBinary() {
  const candidates = [process.env.OLLAMA_EXE, process.env.LOCALAPPDATA && path.join(process.env.LOCALAPPDATA, "Programs", "Ollama", "ollama.exe"), "C:\\Program Files\\Ollama\\ollama.exe"].filter(Boolean);
  for (const c of candidates) if (fs.existsSync(c)) return c;
  return "ollama"; // falls back to PATH
}

// Resolves true when the engine answers. Starts it when needed; memoised while it is up.
function ensure({ modelsDir, log }) {
  if (readyPromise) return readyPromise;
  readyPromise = (async () => {
    if (await ping()) return true;
    let failed = false;
    try {
      fs.mkdirSync(modelsDir, { recursive: true });
      const u = new URL(HOST);
      child = spawn(findBinary(), ["serve"], {
        env: { ...process.env, OLLAMA_HOST: `${u.hostname}:${u.port}`, OLLAMA_MODELS: modelsDir, OLLAMA_KEEP_ALIVE: "-1", OLLAMA_MAX_LOADED_MODELS: "2", OLLAMA_NUM_PARALLEL: process.env.FIDEX_NUM_PARALLEL || "1", OLLAMA_FLASH_ATTENTION: process.env.FIDEX_FLASH || "1", OLLAMA_KV_CACHE_TYPE: process.env.FIDEX_KV_CACHE || "f16" },
        stdio: "ignore",
        windowsHide: true,
      });
      child.on("error", (e) => { failed = true; child = null; log && log.error(`could not start Ollama: ${e.message}`); });
      child.on("exit", () => { child = null; readyPromise = null; });
      log && log.info(`starting local Ollama (models: ${modelsDir})`);
    } catch (e) {
      log && log.error(`could not start Ollama: ${e.message}`);
      return false;
    }
    for (let i = 0; i < 300 && !failed; i++) {
      if (await ping(200)) return true;
      await sleep(50);
    }
    return false;
  })().then((ok) => { if (!ok) readyPromise = null; return ok; });
  return readyPromise;
}

// Loads the model into memory now (same context size as chat, so it is never reloaded).
function warmup(model = CHAT_MODEL) {
  return new Promise((resolve) => {
    const body = JSON.stringify({ model, messages: [], keep_alive: -1, options: { num_ctx: 4096, ...RUNNER } });
    const req = http.request(HOST + "/api/chat", { method: "POST", headers: { "Content-Type": "application/json" } }, (res) => { res.resume(); res.on("end", resolve); });
    req.on("error", resolve);
    req.end(body);
  });
}

function stop() {
  if (child) { try { child.kill(); } catch (_) { /* already gone */ } child = null; }
}

module.exports = { HOST, MODEL, CHAT_MODEL, VISION_MODEL, RUNNER, ensure, warmup, stop, ping };
