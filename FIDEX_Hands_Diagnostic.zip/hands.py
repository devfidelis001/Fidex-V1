"""Windows Hands: real mouse/keyboard control for Take Over, using PyAutoGUI.

Flow (nothing here is simulated):
  hands.start   -> new Take Over session (clears Stop, history, pending actions)
  hands.plan    -> Qwen picks ONE supported action for the instruction (or just answers). The action is
                   validated against the real screen size and registered as pending with an id.
  hands.approve -> the user's decision for that pending action.
  hands.execute -> runs the pending action with PyAutoGUI. Refused unless approved (when approval is required).
                   Returns the real result (or the real error), which is also fed back to Qwen on the next plan.
  hands.stop    -> stops the planner and any running action at once and blocks further execution until hands.start.

PyAutoGUI is imported lazily, so the backend still starts on a machine without a display.
"""
from __future__ import annotations

import json
import logging
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import uuid

from . import ai
from .protocol import INVALID_PAYLOAD, RequestError

log = logging.getLogger("fidex.hands")

HANDS_UNAVAILABLE = "HANDS_UNAVAILABLE"  # PyAutoGUI missing or no screen to control
HANDS_STOPPED = "HANDS_STOPPED"  # the user pressed Stop (or the PyAutoGUI corner fail-safe fired)
APPROVAL_REQUIRED = "APPROVAL_REQUIRED"  # the action was not approved by the user
ACTION_INVALID = "ACTION_INVALID"  # the action is not supported or its values are not valid
ACTION_FAILED = "ACTION_FAILED"  # PyAutoGUI / the OS reported an error while executing
STEP_LIMIT = "STEP_LIMIT"

MAX_STEPS = 12  # actions per instruction; protects against a runaway loop
MAX_TEXT = 500
MAX_HISTORY = 20
TYPE_CHUNK = 20  # characters typed between two Stop checks
TYPE_INTERVAL = 0.02
MAX_WAIT = 10.0
MAX_SCROLL = 5000
APP_NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9 ._\-]{0,59}$")

ACTIONS = ("click", "move", "scroll", "type", "press", "hotkey", "open_app", "wait")
# Everything that changes something on the computer needs the user's approval. Only these never do.
NO_APPROVAL = ("move", "scroll", "wait")

SYSTEM_PROMPT = (
    "You are the decision layer of FIDEX AI Windows Hands. You control the user's Windows mouse and keyboard, one action at a time. "
    "Screen size: {w}x{h} pixels (x from 0 to {wm}, y from 0 to {hm}); the centre is ({cx},{cy}). You cannot see the screen, so you cannot find buttons or windows by sight: "
    "use click/move with coordinates the user gave you OR a place you can compute from the screen size (centre, corners, edges, percentages); otherwise use the keyboard or open_app. "
    "You DO control the real mouse and keyboard through these actions, so never say you cannot, and never offer a Python script or code instead of the action.\n"
    "Supported actions (JSON):\n"
    '  {{"type":"open_app","name":"notepad"}}\n'
    '  {{"type":"type","text":"hello"}}   (ASCII text only)\n'
    '  {{"type":"press","key":"enter"}}\n'
    '  {{"type":"hotkey","keys":["ctrl","s"]}}\n'
    '  {{"type":"click","x":100,"y":200,"button":"left","clicks":1}}\n'
    '  {{"type":"move","x":100,"y":200}}\n'
    '  {{"type":"scroll","amount":-300}}   (negative = down)\n'
    '  {{"type":"wait","seconds":1}}\n'
    'Reply with ONE JSON object only: {{"say":"short sentence for the user","action":<one action or null>,"done":<true when the instruction is fully finished>}}. '
    "Choose exactly one next action. Use the real results of earlier actions listed below; never claim something worked unless its result says ok. "
    "If the instruction needs no action, or it cannot be done with the supported actions, set action to null and explain in say. No markdown."
)


def _pg():
    """Returns the pyautogui module, configured. Raises HANDS_UNAVAILABLE when it cannot be used here."""
    try:
        import pyautogui  # noqa: PLC0415
    except ImportError:
        raise RequestError(HANDS_UNAVAILABLE, "PyAutoGUI is not installed. Run: pip install -r requirements.txt") from None
    except Exception as err:  # noqa: BLE001  (no display, missing Tk/X, ...)
        raise RequestError(HANDS_UNAVAILABLE, f"PyAutoGUI cannot start here: {err}") from None
    pyautogui.FAILSAFE = True  # slam the mouse into a screen corner to abort
    pyautogui.PAUSE = 0.05
    return pyautogui


def screen_size() -> tuple[int, int]:
    pg = _pg()
    try:
        size = pg.size()
        w, h = int(size[0]), int(size[1])
    except Exception as err:  # noqa: BLE001
        raise RequestError(HANDS_UNAVAILABLE, f"Cannot read the screen size: {err}") from None
    if w <= 0 or h <= 0:
        raise RequestError(HANDS_UNAVAILABLE, "The screen size is not available.")
    return w, h


# ---------- validation ----------
def _int(value, name: str, lo: int, hi: int) -> int:
    if isinstance(value, bool) or not isinstance(value, (int, float)) or value != value or abs(value) == float("inf"):
        raise RequestError(ACTION_INVALID, f"'{name}' must be a number.")
    value = int(round(value))
    if not lo <= value <= hi:
        raise RequestError(ACTION_INVALID, f"'{name}' must be between {lo} and {hi} (got {value}).")
    return value


def _key(name, valid) -> str:
    if not isinstance(name, str) or not name.strip():
        raise RequestError(ACTION_INVALID, "A key name is required.")
    key = name.strip().lower()
    aliases = {"control": "ctrl", "return": "enter", "escape": "esc", "windows": "win", "del": "delete", "arrowup": "up", "arrowdown": "down", "arrowleft": "left", "arrowright": "right"}
    key = aliases.get(key, key)
    if key not in valid:
        raise RequestError(ACTION_INVALID, f"'{name}' is not a key PyAutoGUI supports.")
    return key


def normalize_action(raw, size: tuple[int, int], valid_keys) -> dict:
    """Checks one action against the supported list and the real screen size. Returns a clean copy."""
    if not isinstance(raw, dict) or raw.get("type") not in ACTIONS:
        raise RequestError(ACTION_INVALID, f"Unsupported action. Supported: {', '.join(ACTIONS)}.")
    kind, w, h = raw["type"], size[0], size[1]
    if kind in ("click", "move"):
        act = {"type": kind, "x": _int(raw.get("x"), "x", 0, w - 1), "y": _int(raw.get("y"), "y", 0, h - 1)}
        if kind == "click":
            button = raw.get("button", "left")
            if button not in ("left", "right", "middle"):
                raise RequestError(ACTION_INVALID, "'button' must be left, right or middle.")
            act.update(button=button, clicks=_int(raw.get("clicks", 1), "clicks", 1, 3))
        return act
    if kind == "scroll":
        return {"type": kind, "amount": _int(raw.get("amount"), "amount", -MAX_SCROLL, MAX_SCROLL)}
    if kind == "type":
        text = raw.get("text")
        if not isinstance(text, str) or not text:
            raise RequestError(ACTION_INVALID, "'text' must be non-empty text.")
        if len(text) > MAX_TEXT:
            raise RequestError(ACTION_INVALID, f"'text' is longer than {MAX_TEXT} characters.")
        bad = sorted({c for c in text if not (c.isascii() and (c.isprintable() or c in "\n\t"))})
        if bad:
            raise RequestError(ACTION_INVALID, "PyAutoGUI can only type plain ASCII text; unsupported characters: " + "".join(bad[:10]))
        return {"type": kind, "text": text}
    if kind == "press":
        key = raw.get("key")
        if isinstance(key, str) and "+" in key and len(key) > 1:  # "ctrl+s" given as a single key
            return normalize_action({"type": "hotkey", "keys": key.split("+")}, size, valid_keys)
        return {"type": kind, "key": _key(key, valid_keys)}
    if kind == "hotkey":
        keys = raw.get("keys")
        if not isinstance(keys, list) or not 2 <= len(keys) <= 4:
            raise RequestError(ACTION_INVALID, "'keys' must be a list of 2 to 4 keys.")
        return {"type": kind, "keys": [_key(k, valid_keys) for k in keys]}
    if kind == "open_app":
        name = raw.get("name")
        if not isinstance(name, str) or not APP_NAME_RE.match(name.strip()):
            raise RequestError(ACTION_INVALID, "'name' must be a plain application name such as notepad, calc or chrome.")
        return {"type": kind, "name": name.strip()}
    seconds = raw.get("seconds", 1)
    if isinstance(seconds, bool) or not isinstance(seconds, (int, float)) or not 0 <= seconds <= MAX_WAIT:
        raise RequestError(ACTION_INVALID, f"'seconds' must be a number from 0 to {MAX_WAIT:g}.")
    return {"type": "wait", "seconds": float(seconds)}


def requires_approval(action: dict) -> bool:
    return action["type"] not in NO_APPROVAL


def describe(action: dict) -> str:
    k = action["type"]
    if k == "click":
        return f"{action['button']}-click{' x' + str(action['clicks']) if action['clicks'] > 1 else ''} at ({action['x']}, {action['y']})"
    if k == "move":
        return f"move the mouse to ({action['x']}, {action['y']})"
    if k == "scroll":
        return f"scroll {action['amount']}"
    if k == "type":
        t = action["text"]
        return "type " + json.dumps(t if len(t) <= 80 else t[:77] + "...")
    if k == "press":
        return f"press {action['key']}"
    if k == "hotkey":
        return "press " + "+".join(action["keys"])
    if k == "open_app":
        return f"open {action['name']}"
    return f"wait {action['seconds']:g}s"


# ---------- session ----------
class Session:
    def __init__(self):
        self.lock = threading.RLock()
        self.exec_lock = threading.Lock()  # one real action at a time
        self.stopped = threading.Event()
        self.history: list[dict] = []
        self.pending: dict[str, dict] = {}
        self.goals: list[str] = []
        self.steps = 0
        self.planner_stream = ""

    def start(self) -> None:
        with self.lock:
            self.stopped.clear()
            self.history, self.pending, self.goals, self.steps = [], {}, [], 0

    def record(self, entry: dict) -> None:
        with self.lock:
            self.history.append(entry)
            del self.history[:-MAX_HISTORY]


SESSION = Session()


def status() -> dict:
    try:
        w, h = screen_size()
    except RequestError as err:
        return {"available": False, "platform": sys.platform, "error": {"code": err.code, "message": err.message}}
    return {"available": True, "platform": sys.platform, "screen": {"width": w, "height": h}}


def start() -> dict:
    SESSION.start()
    return status()


def stop() -> dict:
    """Stops everything at once: the planner's model call, and any action that is typing/waiting."""
    SESSION.stopped.set()
    with SESSION.lock:
        sid = SESSION.planner_stream
        SESSION.pending.clear()
    if sid:
        ai.cancel(sid)
    log.info("hands stopped by the user")
    return {"stopped": True}


def _check_stopped() -> None:
    if SESSION.stopped.is_set():
        raise RequestError(HANDS_STOPPED, "Stopped by the user.")


# ---------- planning (Qwen decides) ----------
def _history_text() -> str:
    with SESSION.lock:
        items = list(SESSION.history[-8:])
    if not items:
        return "(no actions yet)"
    return "\n".join(f"- {i['action']}: " + ("ok" + (f" ({i['detail']})" if i.get("detail") else "") if i["ok"] else f"FAILED: {i['error']}") if "action" in i else f"- user: {i['note']}" for i in items)


def parse_plan(text: str) -> dict:
    start_i, end_i = text.find("{"), text.rfind("}")
    if start_i < 0 or end_i <= start_i:
        return {"say": text.strip()[:600], "action": None, "done": False}
    try:
        obj = json.loads(text[start_i : end_i + 1])
    except ValueError:
        return {"say": text.strip()[:600], "action": None, "done": False}
    if not isinstance(obj, dict):
        return {"say": text.strip()[:600], "action": None, "done": False}
    say = obj.get("say")
    return {"say": say.strip()[:600] if isinstance(say, str) else "", "action": obj.get("action"), "done": obj.get("done") is True}


def _ask_qwen(messages: list[dict]) -> str:
    sid = "hands-" + uuid.uuid4().hex[:12]
    stream = ai._register(sid)
    with SESSION.lock:
        SESSION.planner_stream = sid
    try:
        got = False
        while not got:
            got = ai._gen_lock.acquire(timeout=0.1)
            if not got and SESSION.stopped.is_set():
                break
        if not got:
            raise RequestError(HANDS_STOPPED, "Stopped by the user.")
        try:
            if SESSION.stopped.is_set():
                raise RequestError(HANDS_STOPPED, "Stopped by the user.")
            text, timings = ai._stream_ask(messages, lambda t: None, think=False, stream=stream)
        finally:
            ai._gen_lock.release()
    finally:
        ai._unregister(sid)
        with SESSION.lock:
            SESSION.planner_stream = ""
    if SESSION.stopped.is_set() or timings.get("cancelled"):
        raise RequestError(HANDS_STOPPED, "Stopped by the user.")
    return text


def plan(instruction=None) -> dict:
    """Qwen decides the next supported action. instruction=None continues the current one using the real results so far."""
    _check_stopped()
    if instruction is not None:
        if not isinstance(instruction, str) or not instruction.strip():
            raise RequestError(INVALID_PAYLOAD, "'instruction' must be non-empty text.")
        instruction = instruction.strip()[:2000]
        with SESSION.lock:
            SESSION.goals.append(instruction)
            del SESSION.goals[:-4]
            SESSION.steps = 0
    elif not SESSION.goals:
        raise RequestError(INVALID_PAYLOAD, "No instruction yet.")
    with SESSION.lock:
        if SESSION.steps >= MAX_STEPS:
            return {"say": f"I stopped after {MAX_STEPS} actions without finishing. Tell me how to continue.", "action": None, "done": True, "limit": True}
        goals = list(SESSION.goals)
    w, h = screen_size()
    pg = _pg()
    system = SYSTEM_PROMPT.format(w=w, h=h, wm=w - 1, hm=h - 1, cx=w // 2, cy=h // 2)
    user = "User instructions (oldest first):\n" + "\n".join(f"{i + 1}. {g}" for i, g in enumerate(goals)) + "\n\nReal results of earlier actions:\n" + _history_text() + "\n\nDecide the next step for the latest instruction."
    parsed = parse_plan(_ask_qwen([{"role": "system", "content": system}, {"role": "user", "content": user}]))
    action = None
    if parsed["action"] is not None:
        try:
            action = normalize_action(parsed["action"], (w, h), pg.KEYBOARD_KEYS)
        except RequestError as err:
            SESSION.record({"action": "planned an unsupported action", "ok": False, "error": err.message})
            return {"say": f"I cannot do that: {err.message}", "action": None, "done": False, "invalid": err.message}
    _check_stopped()
    out = {"say": parsed["say"], "action": None, "done": parsed["done"] and action is None, "screen": {"width": w, "height": h}}
    if action is not None:
        out["action"] = register(action)
    return out


def register(action: dict) -> dict:
    """Registers an already-validated action as pending. Approval rules are unchanged: see requires_approval()."""
    aid = uuid.uuid4().hex[:12]
    needs = requires_approval(action)
    with SESSION.lock:
        SESSION.pending[aid] = {"action": action, "approved": not needs, "needs_approval": needs, "used": False}
        SESSION.steps += 1
    return {"id": aid, "describe": describe(action), "requires_approval": needs, **action}


def propose(raw_action, instruction: str | None = None) -> dict:
    """Validates an action chosen by the Action Decision Engine exactly like a Qwen-planned one and registers it as pending.
    It is NOT executed here: hands.approve / hands.execute still apply."""
    _check_stopped()
    if instruction:
        with SESSION.lock:
            SESSION.goals.append(instruction[:2000])
            del SESSION.goals[:-4]
            SESSION.steps = 0
    w, h = screen_size()
    action = normalize_action(raw_action, (w, h), _pg().KEYBOARD_KEYS)
    return register(action)


def approve(action_id, approved) -> dict:
    if not isinstance(approved, bool):
        raise RequestError(INVALID_PAYLOAD, "'approved' must be true or false.")
    with SESSION.lock:
        entry = SESSION.pending.get(action_id) if isinstance(action_id, str) else None
        if entry is None:
            raise RequestError(INVALID_PAYLOAD, "Unknown or expired action id.")
        if approved:
            _check_stopped()
            entry["approved"] = True
        else:
            SESSION.pending.pop(action_id, None)
            SESSION.record({"action": describe(entry["action"]), "ok": False, "error": "the user declined this action"})
    return {"id": action_id, "approved": approved}


# ---------- execution ----------
def _open_app(name: str) -> str:
    if sys.platform == "win32":
        os.startfile(name)  # type: ignore[attr-defined]  # ShellExecute: resolves App Paths and PATH like the Run box
        return "launch requested from Windows (not verified that a window appeared)"
    path = shutil.which(name)
    if not path:
        raise RequestError(ACTION_FAILED, f"'{name}' was not found on this computer.")
    subprocess.Popen([path], stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
    return f"started {path}"


def _sleep(seconds: float) -> float:
    end, done = time.monotonic() + seconds, 0.0
    while True:
        left = end - time.monotonic()
        if left <= 0 or SESSION.stopped.is_set():
            break
        time.sleep(min(0.05, left))
    return round(seconds - max(0.0, end - time.monotonic()), 2)


def _run(pg, action: dict) -> tuple[str, dict]:
    k = action["type"]
    if k in ("click", "move"):
        pg.moveTo(action["x"], action["y"], duration=0.15)
        _check_stopped()
        if k == "click":
            pg.click(action["x"], action["y"], clicks=action["clicks"], button=action["button"])
        pos = pg.position()
        return f"pointer at ({pos[0]}, {pos[1]})", {"x": int(pos[0]), "y": int(pos[1])}
    if k == "scroll":
        pg.scroll(action["amount"])
        return f"scrolled {action['amount']}", {"scrolled": action["amount"]}
    if k == "type":
        text, typed = action["text"], 0
        for i in range(0, len(text), TYPE_CHUNK):
            _check_stopped()
            chunk = text[i : i + TYPE_CHUNK]
            pg.write(chunk, interval=TYPE_INTERVAL)
            typed += len(chunk)
        return f"typed {typed} characters", {"typed": typed}
    if k == "press":
        pg.press(action["key"])
        return f"pressed {action['key']}", {"pressed": action["key"]}
    if k == "hotkey":
        pg.hotkey(*action["keys"])
        return "pressed " + "+".join(action["keys"]), {"pressed": "+".join(action["keys"])}
    if k == "open_app":
        detail = _open_app(action["name"])
        return detail, {"app": action["name"]}
    waited = _sleep(action["seconds"])
    _check_stopped()
    return f"waited {waited}s", {"waited": waited}


def execute(action_id) -> dict:
    """Runs one planned action for real and returns what really happened (also remembered for the next plan)."""
    _check_stopped()
    with SESSION.lock:
        entry = SESSION.pending.get(action_id) if isinstance(action_id, str) else None
        if entry is None or entry["used"]:
            raise RequestError(INVALID_PAYLOAD, "Unknown, expired or already executed action id.")
        if entry["needs_approval"] and not entry["approved"]:
            raise RequestError(APPROVAL_REQUIRED, "The user has not approved this action.")
        entry["used"] = True
        action = entry["action"]
    label = describe(action)
    pg = _pg()
    started = time.monotonic()
    result = {"ok": False, "action": action, "describe": label}
    with SESSION.exec_lock:
        try:
            _check_stopped()
            w, h = screen_size()  # re-check: the screen may have changed since planning
            if action["type"] in ("click", "move") and not (0 <= action["x"] < w and 0 <= action["y"] < h):
                raise RequestError(ACTION_INVALID, f"({action['x']}, {action['y']}) is outside the screen ({w}x{h}).")
            detail, data = _run(pg, action)
            result.update(ok=True, detail=detail, data=data)
        except RequestError as err:
            result.update(error={"code": err.code, "message": err.message})
        except Exception as err:  # noqa: BLE001
            if type(err).__name__ == "FailSafeException":
                SESSION.stopped.set()
                result.update(error={"code": HANDS_STOPPED, "message": "Stopped: the mouse was moved to a screen corner (PyAutoGUI fail-safe)."})
            else:
                log.exception("hands action failed")
                result.update(error={"code": ACTION_FAILED, "message": f"{type(err).__name__}: {err}"})
    with SESSION.lock:
        SESSION.pending.pop(action_id, None)
    result["duration_ms"] = round((time.monotonic() - started) * 1000)
    try:
        result["screen"] = dict(zip(("width", "height"), screen_size()))
    except RequestError:
        pass
    SESSION.record({"action": label, "ok": result["ok"], "detail": result.get("detail", ""), "error": result.get("error", {}).get("message", "")})
    log.info("hands executed %s ok=%s", label, result["ok"])
    return result
