// Windows Hands client for Take Over. Qwen (via the backend) decides ONE supported action at a time; every action needs the
// user's approval in the panel (except move/scroll/wait), runs for real in the backend (PyAutoGUI) and the REAL result goes back
// to Qwen for the next decision. Nothing is simulated: if Hands is unavailable, available() is false and Take Over keeps chatting only.
import { bridge } from "./bridge.js";

export function createHandsAgent({ sim, say }) {
  let runId = 0; // bumped by stop(): a running loop notices and quits
  let started = false;
  let waiting = null; // {id, resolve} while an approval is open
  let availability = null;

  const alive = (id) => id === runId;

  async function available() {
    if (availability !== true) { // only a positive answer is cached: a backend that was still starting must not disable Hands for good
      const res = await bridge.backendRequest("hands.status", {});
      availability = Boolean(res.ok && res.data && res.data.available);
    }
    return availability;
  }

  // Called with every panel state: resolves the open approval when the user clicked Approve/Decline.
  function onState(state) {
    if (!waiting || !state) return;
    const r = state.requests.find((x) => x.id === waiting.id);
    if (r && r.state === "answered") {
      const w = waiting;
      waiting = null;
      w.resolve(r.answer === "approved");
    }
  }

  function askApproval(action) {
    return new Promise((resolve) => {
      const id = "hands-" + action.id;
      waiting = { id, resolve };
      sim.addRequest({ id, kind: "approval", text: `Allow FIDEX AI to ${action.describe}?`, detail: "This will really control your mouse or keyboard on this computer. Press Stop at any time, or move the mouse into a screen corner.", blocks: true });
    });
  }

  // Runs one instruction to the end: plan -> approve -> execute -> feed result -> plan ... until Qwen says it is done.
  async function run(instruction) {
    const me = runId;
    if (!started) {
      started = true;
      await bridge.backendRequest("hands.start", {});
    }
    let next = instruction;
    while (alive(me)) {
      sim.setActivity("Deciding the next step...");
      // A new instruction goes through the Action Decision Engine (same shape as hands.plan, plus needs_action/tool/params);
      // follow-up steps keep using hands.plan with the real results.
      const planned = next == null ? await bridge.backendRequest("hands.plan", {}) : await bridge.backendRequest("action.decide", { instruction: next });
      next = null;
      if (!alive(me)) return;
      if (!planned.ok) {
        sim.setActivity("");
        if (!planned.error || planned.error.code !== "HANDS_STOPPED") say(planned.error ? planned.error.message : "Hands could not plan the next step.");
        return;
      }
      const plan = planned.data;
      if (plan.source === "none") { sim.setActivity(""); return "chat"; } // the engine found no action needed: normal conversation
      if (plan.say) say(plan.say);
      const action = plan.action;
      if (!action) {
        sim.setActivity("");
        if (plan.done) sim.complete(plan.say || "Finished");
        return;
      }
      if (action.requires_approval) {
        sim.setActivity(`Waiting for your approval to ${action.describe}`);
        const ok = await askApproval(action);
        if (!alive(me)) return;
        const decided = await bridge.backendRequest("hands.approve", { action_id: action.id, approved: ok });
        if (!decided.ok && ok) {
          say(decided.error.message);
          return;
        }
        if (!ok) {
          say(`Declined: ${action.describe}. Nothing was done.`);
          next = null; // Qwen sees the declined result and decides what to do instead
          continue;
        }
      }
      sim.setActivity(`Doing: ${action.describe}`);
      const res = await bridge.backendRequest("hands.execute", { action_id: action.id });
      if (!alive(me)) return;
      const out = res.ok ? res.data : { ok: false, error: res.error };
      if (out.ok) say(`Done: ${action.describe}. ${out.detail || ""}`.trim());
      else {
        sim.setActivity("");
        say(`Failed: ${action.describe}. ${out.error ? out.error.message : "Unknown error."}`);
        if (out.error && out.error.code === "HANDS_STOPPED") return;
      }
    }
  }

  return {
    available,
    onState,
    run,
    // Stop: ends the loop, rejects any open approval and tells the backend to halt planning and typing immediately.
    stop() {
      runId++;
      waiting = null;
      started = false;
      return bridge.backendRequest("hands.stop", {});
    },
  };
}
