"""Windows Hands requests (real mouse/keyboard control for Take Over; see hands.py).

    hands.status   {}                      ->  {available, platform, screen:{width,height}} (or error when unavailable)
    hands.start    {}                      ->  same as status; starts a fresh Take Over session
    hands.plan     {instruction?}          ->  {say, action|null, done}. Qwen picks the next supported action; action has id, describe, requires_approval
    hands.approve  {action_id, approved}   ->  {id, approved}
    hands.execute  {action_id}             ->  {ok, detail|error, action, duration_ms, screen, data}  (the REAL result)
    hands.stop     {}                      ->  {stopped: true}. Stops planning and any running action at once
"""
from __future__ import annotations

from . import hands
from .handlers import handler
from .protocol import INVALID_PAYLOAD, RequestError


def _only(payload: dict, allowed: tuple) -> None:
    for key in payload:
        if key not in allowed:
            raise RequestError(INVALID_PAYLOAD, f"Unknown field '{key}'.")


@handler("hands.status")
def hands_status(payload: dict) -> dict:
    _only(payload, ())
    return hands.status()


@handler("hands.start")
def hands_start(payload: dict) -> dict:
    _only(payload, ())
    return hands.start()


@handler("hands.plan")
def hands_plan(payload: dict) -> dict:
    _only(payload, ("instruction",))
    return hands.plan(payload.get("instruction"))


@handler("hands.approve")
def hands_approve(payload: dict) -> dict:
    _only(payload, ("action_id", "approved"))
    return hands.approve(payload.get("action_id"), payload.get("approved"))


@handler("hands.execute")
def hands_execute(payload: dict) -> dict:
    _only(payload, ("action_id",))
    return hands.execute(payload.get("action_id"))


@handler("hands.stop")
def hands_stop(payload: dict) -> dict:
    _only(payload, ())
    return hands.stop()
