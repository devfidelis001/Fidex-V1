// PLACEHOLDER RESPONDER.
// This is the single place where chat replies come from. It does NOT use any AI.
// In a later step this function is replaced by the real FIDEX AI brain;
// nothing else in the interface needs to change.
//
// v0.9.0: the details saved under "Give Me Your Details" are read here (getBrainContext) so the
// brain receives them with every question. Until the AI engine exists, simple questions about
// the user themselves are answered straight from those saved details.

import { FIELDS, profileSummary, greetingName } from "./profile.js";
import { loadProfile } from "./storage.js";

// What the brain gets alongside the user's message.
export function getBrainContext() {
  return profileSummary(loadProfile());
}

const ABOUT_ME = [
  { re: /\b(my name|who am i|call me)\b/i, keys: ["name", "preferredName"] },
  { re: /\b(my (job|role|title|work|profession)|what do i do)\b/i, keys: ["role", "company", "industry"] },
  { re: /\b(my (company|business|employer))\b/i, keys: ["company", "industry"] },
  { re: /\b(my (skills?|expertise)|what am i good at)\b/i, keys: ["skills"] },
  { re: /\b(my (goals?|projects?))\b/i, keys: ["goals"] },
  { re: /\b(where do i live|my (location|city|time ?zone))\b/i, keys: ["location"] },
  { re: /\b(what do you know about me|about me)\b/i, keys: FIELDS.map((f) => f.key) },
];

function answerFromDetails(userText, profile) {
  for (const rule of ABOUT_ME) {
    if (!rule.re.test(userText)) continue;
    const parts = rule.keys.filter((k) => profile[k]).map((k) => `${FIELDS.find((f) => f.key === k).label}: ${profile[k]}`);
    if (parts.length) return `From the details you gave me:\n${parts.join("\n")}`;
    return "I do not have that saved yet. You can add it under \"Give Me Your Details\".";
  }
  return null;
}

export async function getReply(conversation, userText) {
  const profile = loadProfile();
  const known = answerFromDetails(userText, profile);
  if (known) return { placeholder: false, text: known };

  const name = greetingName(profile);
  const preview = userText.length > 120 ? userText.slice(0, 120) + "..." : userText;
  return {
    placeholder: true,
    text:
      (name ? `${name}, this ` : "This ") +
      "is a placeholder reply. FIDEX AI's brain is not connected yet, " +
      "so no real AI wrote this message.\n\nYour message was received: \"" + preview + "\"" +
      (getBrainContext() ? "\n\nYour saved details will be sent to the brain with this message once it is connected." : ""),
  };
}
